-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Gegenereerd op: 13 jan 2016 om 21:38
-- Serverversie: 5.6.25
-- PHP-versie: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jurassic_terrarium`
--
CREATE DATABASE IF NOT EXISTS `jurassic_terrarium` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `jurassic_terrarium`;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `username` varchar(10) COLLATE utf8_bin NOT NULL,
  `password` varchar(10) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Gegevens worden geëxporteerd voor tabel `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `simulations`
--

CREATE TABLE IF NOT EXISTS `simulations` (
  `id` int(11) NOT NULL,
  `arrays` varchar(20) COLLATE utf8_bin NOT NULL,
  `completion_time` int(11) NOT NULL,
  `start_plants` int(11) NOT NULL,
  `start_carnivores` int(11) NOT NULL,
  `start_herbivores` int(11) NOT NULL,
  `surviver` varchar(3) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `winners`
--

CREATE TABLE IF NOT EXISTS `winners` (
  `id` int(10) NOT NULL,
  `surviver` varchar(3) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Gegevens worden geëxporteerd voor tabel `winners`
--

INSERT INTO `winners` (`id`, `surviver`) VALUES
(1, 'chp'),
(2, 'ch'),
(3, 'cp'),
(4, 'hp'),
(5, 'c'),
(6, 'h'),
(7, 'p');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `winners`
--
ALTER TABLE `winners`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `winners`
--
ALTER TABLE `winners`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
