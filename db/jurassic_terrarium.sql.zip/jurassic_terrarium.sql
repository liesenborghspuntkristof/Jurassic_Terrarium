--
-- Database: `jurassic_terrarium`
drop DATABASE IF EXISTS `jurassic_terrarium`;
CREATE DATABASE IF NOT EXISTS `jurassic_terrarium` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `jurassic_terrarium`;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `admin`
--

CREATE TABLE `admin` (
  `username` varchar(10) COLLATE utf8_bin NOT NULL,
  `password` varchar(10) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Gegevens worden geëxporteerd voor tabel `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `organisms`
--

CREATE TABLE `organisms` (
  `id` int(11) NOT NULL,
  `session_id` text NOT NULL,
  `type` varchar(15) NOT NULL,
  `day` int(5) NOT NULL,
  `life` int(5) NOT NULL,
  `positionX` int(5) NOT NULL,
  `positionY` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `simulations`
--

CREATE TABLE `simulations` (
  `session_id` text COLLATE utf8_bin NOT NULL,
  `count_plants` int(10) NOT NULL,
  `count_carnivores` int(10) NOT NULL,
  `count_herbivores` int(10) NOT NULL,
  `surviver` varchar(3) COLLATE utf8_bin DEFAULT NULL,
  `count_days` int(10) NOT NULL,
  `dimensions` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `organisms`
--
ALTER TABLE `organisms`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `organisms`
--
ALTER TABLE `organisms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

